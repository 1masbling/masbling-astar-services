import { useState, useMemo, useRef } from 'react';
import {
  FileText, Plus, X, Send, CheckCircle2, XCircle, Trash2,
  ChevronRight, Clock, Printer, Sparkles,
} from 'lucide-react';
import { useData } from '@/lib/data';
import { formatCurrency, formatDate, formatShortDate } from '@/lib/format';
import { ESTIMATE_STATUSES, COMPANY } from '@/lib/constants';
import type { Estimate, EstimateLineItem, EstimateStatus, Customer } from '@/lib/types';
import EstimateTemplate from '@/components/EstimateTemplate';

const SERVICE_PRESETS: Record<string, { description: string; quantity: string; unit_price: string }[]> = {
  'Gutter Cleaning': [
    { description: 'Gutter cleaning — full perimeter, remove leaves & debris', quantity: '1', unit_price: '185' },
    { description: 'Downspout flush & flow check', quantity: '1', unit_price: '45' },
    { description: 'Minor re-secure of loose brackets (up to 5)', quantity: '1', unit_price: '35' },
  ],
  'Window Caulking': [
    { description: 'Window perimeter re-caulking — exterior sealant replacement', quantity: '1', unit_price: '145' },
    { description: 'Caulking — additional window (same visit)', quantity: '0', unit_price: '75' },
  ],
  'Window Cleaning': [
    { description: 'Exterior window cleaning (streak-free)', quantity: '1', unit_price: '120' },
    { description: 'Interior + exterior window cleaning', quantity: '1', unit_price: '195' },
    { description: 'Screen cleaning & reinstallation', quantity: '1', unit_price: '40' },
  ],
  'Downpipe Service': [
    { description: 'Downpipe repair / replacement (per section)', quantity: '1', unit_price: '95' },
    { description: 'Downpipe extension installation', quantity: '1', unit_price: '65' },
  ],
  'Vent Cleaning': [
    { description: 'Dryer vent cleaning — full line, lint removal', quantity: '1', unit_price: '135' },
    { description: 'Bathroom/kitchen exhaust vent cleaning', quantity: '1', unit_price: '85' },
  ],
  'Leak Sealing': [
    { description: 'Leak detection & inspection', quantity: '1', unit_price: '95' },
    { description: 'Leak sealing — waterproof sealant application', quantity: '1', unit_price: '175' },
  ],
  'Handyman Fixes': [
    { description: 'General handyman labour (per hour)', quantity: '2', unit_price: '65' },
    { description: 'Drywall patch & paint touch-up', quantity: '1', unit_price: '120' },
    { description: 'Door adjustment / fixture installation', quantity: '1', unit_price: '85' },
  ],
};

export default function Estimates() {
  const { estimates, lineItems, customers, addEstimate, updateEstimate, addNotification } = useData();
  const [filter, setFilter] = useState<EstimateStatus | 'all'>('all');
  const [showAdd, setShowAdd] = useState(false);
  const [viewEstimate, setViewEstimate] = useState<Estimate | null>(null);

  const filtered = useMemo(() => {
    if (filter === 'all') return estimates;
    return estimates.filter(e => e.status === filter);
  }, [estimates, filter]);

  const stats = useMemo(() => {
    const total = estimates.length;
    const sent = estimates.filter(e => e.status === 'sent').length;
    const approved = estimates.filter(e => e.status === 'approved').length;
    const approvedValue = estimates.filter(e => e.status === 'approved').reduce((s, e) => s + e.total, 0);
    return { total, sent, approved, approvedValue };
  }, [estimates]);

  const itemsFor = (estId: string) => lineItems.filter(li => li.estimate_id === estId);

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-lg font-bold text-navy-50 font-display">Estimates</h2>
        <button onClick={() => setShowAdd(true)} className="btn-primary"><Plus className="w-4 h-4" /> New Estimate</button>
      </div>

      <div className="grid grid-cols-4 gap-2">
        <div className="card p-3"><p className="text-xs text-navy-300">Total</p><p className="text-base font-bold text-navy-50 font-display">{stats.total}</p></div>
        <div className="card p-3"><p className="text-xs text-navy-300">Sent</p><p className="text-base font-bold text-teal-300 font-display">{stats.sent}</p></div>
        <div className="card p-3"><p className="text-xs text-navy-300">Approved</p><p className="text-base font-bold text-success-300 font-display">{stats.approved}</p></div>
        <div className="card p-3"><p className="text-xs text-navy-300">Approved Value</p><p className="text-base font-bold text-gold-400 font-display">{formatCurrency(stats.approvedValue)}</p></div>
      </div>

      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        <button onClick={() => setFilter('all')} className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition-all ${filter === 'all' ? 'bg-gold-400 text-black' : 'bg-navy-800 text-navy-300 hover:bg-navy-700'}`}>All</button>
        {ESTIMATE_STATUSES.map(s => (
          <button key={s.key} onClick={() => setFilter(s.key)} className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition-all ${filter === s.key ? 'bg-gold-400 text-black' : 'bg-navy-800 text-navy-300 hover:bg-navy-700'}`}>{s.label}</button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.map(est => {
          const statusCfg = ESTIMATE_STATUSES.find(s => s.key === est.status);
          const items = itemsFor(est.id);
          return (
            <div key={est.id} className="card card-hover p-3">
              <div className="flex items-start justify-between gap-2">
                <button onClick={() => setViewEstimate(est)} className="flex items-center gap-3 min-w-0 text-left flex-1">
                  <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-navy-700 shrink-0">
                    <FileText className="w-5 h-5 text-gold-400" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-navy-50 truncate">{est.number}</p>
                    <p className="text-xs text-navy-300 truncate">{est.customer_name} · {items.length} item{items.length !== 1 ? 's' : ''}</p>
                  </div>
                </button>
                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-right">
                    <p className="text-sm font-bold text-gold-400">{formatCurrency(est.total)}</p>
                    <span className={`inline-flex items-center rounded-full ${statusCfg?.bg} ${statusCfg?.color} px-2 py-0.5 text-[10px] font-bold`}>{statusCfg?.label}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-navy-500" />
                </div>
              </div>
              <div className="flex items-center gap-3 mt-2 text-[10px] text-navy-400">
                {est.sent_at && <span className="flex items-center gap-1"><Send className="w-3 h-3" /> Sent {formatShortDate(est.sent_at)}</span>}
                {est.expires_at && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Expires {formatShortDate(est.expires_at)}</span>}
              </div>
              {est.status === 'draft' && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-navy-700">
                  <button onClick={() => { updateEstimate(est.id, { status: 'sent' }); if (est.customer_name) { const c = customers.find(cu => cu.name === est.customer_name); addNotification({ type: 'email', recipient: c?.email || '', recipient_name: est.customer_name, subject: `Estimate ${est.number}`, body: `Your estimate for ${formatCurrency(est.total)} has been sent. Please review and approve at your earliest convenience. — Masbling Astar Services`, status: 'sent', related_job_id: null, related_invoice_id: null }); } }} className="text-xs font-semibold text-teal-400 hover:text-teal-300 flex items-center gap-1"><Send className="w-3 h-3" /> Send to Customer</button>
                </div>
              )}
              {est.status === 'sent' && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-navy-700">
                  <button onClick={() => updateEstimate(est.id, { status: 'approved' })} className="text-xs font-semibold text-success-400 hover:text-success-300 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Mark Approved</button>
                  <button onClick={() => updateEstimate(est.id, { status: 'declined' })} className="text-xs font-semibold text-error-400 hover:text-error-300 flex items-center gap-1"><XCircle className="w-3 h-3" /> Decline</button>
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="card p-8 text-center"><FileText className="w-8 h-8 text-navy-600 mx-auto mb-2" /><p className="text-sm text-navy-300">No estimates yet. Create your first estimate.</p></div>
        )}
      </div>

      {viewEstimate && (
        <EstimateDetailDrawer
          estimate={viewEstimate}
          items={itemsFor(viewEstimate.id)}
          customer={customers.find(c => c.name === viewEstimate.customer_name)}
          onClose={() => setViewEstimate(null)}
        />
      )}

      {showAdd && (
        <EstimateFormModal
          customers={customers}
          onClose={() => setShowAdd(false)}
          onSave={async (est, items) => { await addEstimate(est, items); setShowAdd(false); }}
        />
      )}
    </div>
  );
}

function EstimateDetailDrawer({ estimate, items, customer, onClose }: {
  estimate: Estimate;
  items: EstimateLineItem[];
  customer?: Customer;
  onClose: () => void;
}) {
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-navy-950/80 backdrop-blur-sm p-0 md:p-4" onClick={onClose}>
      <div className="card w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-b-none md:rounded-2xl animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 z-20 bg-navy-800/95 backdrop-blur-sm border-b border-navy-700 px-5 py-4 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-navy-50">{estimate.number}</h3>
            <p className="text-xs text-navy-300">{estimate.customer_name}</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="btn-secondary text-xs px-3 py-2 flex items-center gap-1.5">
              <Printer className="w-3.5 h-3.5" /> Print / PDF
            </button>
            <button onClick={onClose} className="btn-ghost p-2"><X className="w-4 h-4" /></button>
          </div>
        </div>
        <div className="px-5 py-4 space-y-4">
          <div className="flex items-center gap-2 flex-wrap">
            {ESTIMATE_STATUSES.find(s => s.key === estimate.status) && (
              <span className={`inline-flex items-center rounded-full ${ESTIMATE_STATUSES.find(s => s.key === estimate.status)?.bg} ${ESTIMATE_STATUSES.find(s => s.key === estimate.status)?.color} px-2.5 py-1 text-xs font-bold`}>{ESTIMATE_STATUSES.find(s => s.key === estimate.status)?.label}</span>
            )}
            {estimate.sent_at && <span className="text-xs text-navy-400">Sent {formatDate(estimate.sent_at)}</span>}
            {estimate.expires_at && <span className="text-xs text-navy-400">Expires {formatDate(estimate.expires_at)}</span>}
          </div>

          <div className="rounded-xl border border-navy-700 overflow-hidden">
            <EstimateTemplate ref={printRef} estimate={estimate} items={items} customer={customer} />
          </div>

          {estimate.status === 'draft' && (
            <button onClick={() => { window.print(); }} className="btn-primary w-full text-sm py-3">
              <Printer className="w-4 h-4" /> Print Estimate for Customer
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function EstimateFormModal({ customers, onClose, onSave }: {
  customers: Customer[];
  onClose: () => void;
  onSave: (est: Omit<Estimate, 'id' | 'created_at' | 'line_items'>, items: Omit<EstimateLineItem, 'id' | 'estimate_id' | 'created_at'>[]) => Promise<void>;
}) {
  const [customerId, setCustomerId] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [taxRate, setTaxRate] = useState('13');
  const [expiresAt, setExpiresAt] = useState('');
  const [items, setItems] = useState<{ description: string; quantity: string; unit_price: string }[]>([{ description: '', quantity: '1', unit_price: '0' }]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const customer = customers.find(c => c.id === customerId);
  const subtotal = items.reduce((s, it) => s + (parseFloat(it.quantity) || 0) * (parseFloat(it.unit_price) || 0), 0);
  const total = subtotal * (1 + (parseFloat(taxRate) || 0) / 100);

  const updateItem = (idx: number, field: 'description' | 'quantity' | 'unit_price', val: string) => {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, [field]: val } : it));
  };
  const addItem = () => setItems(prev => [...prev, { description: '', quantity: '1', unit_price: '0' }]);
  const removeItem = (idx: number) => setItems(prev => prev.filter((_, i) => i !== idx));

  const applyPreset = (presetName: string) => {
    const preset = SERVICE_PRESETS[presetName];
    if (preset) setItems(preset.map(p => ({ ...p })));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerId) { setError('Please select a customer'); return; }
    if (items.some(it => !it.description.trim())) { setError('All line items need a description'); return; }
    setSaving(true);
    setError(null);
    try {
      const nextNum = `EST-2026-${String(Date.now()).slice(-3)}`;
      await onSave({
        number: nextNum,
        customer_id: customerId,
        customer_name: customer?.name || '',
        job_id: null,
        status: 'draft',
        subtotal,
        tax_rate: parseFloat(taxRate) || 0,
        total,
        notes: notes.trim(),
        sent_at: null,
        expires_at: expiresAt || null,
      }, items.map(it => ({
        description: it.description.trim(),
        quantity: parseFloat(it.quantity) || 1,
        unit_price: parseFloat(it.unit_price) || 0,
        sort_order: 0,
      })));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save estimate');
    } finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-navy-950/80 backdrop-blur-sm p-0 md:p-4" onClick={onClose}>
      <div className="card w-full max-w-lg max-h-[92vh] overflow-y-auto rounded-b-none md:rounded-2xl p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-navy-50">New Estimate</h3>
          <button onClick={onClose} className="btn-ghost p-1.5"><X className="w-4 h-4" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div><label className="label">Customer *</label>
            <select className="input" value={customerId} onChange={e => setCustomerId(e.target.value)}>
              <option value="">Select a customer...</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {/* Service Presets */}
          <div>
            <label className="label flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-gold-400" /> Quick-Start Templates</label>
            <div className="flex items-center gap-1.5 flex-wrap">
              {Object.keys(SERVICE_PRESETS).map(name => (
                <button
                  key={name}
                  type="button"
                  onClick={() => applyPreset(name)}
                  className="rounded-lg bg-navy-700 hover:bg-navy-600 border border-navy-600 px-2.5 py-1.5 text-xs font-medium text-navy-100 transition-all"
                >
                  {name}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-navy-500 mt-1.5">Click a template to pre-fill line items. Adjust quantities and prices as needed.</p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="label mb-0">Line Items</label>
              <button type="button" onClick={addItem} className="text-xs font-semibold text-gold-400 hover:text-gold-300 flex items-center gap-1"><Plus className="w-3 h-3" /> Add Item</button>
            </div>
            <div className="space-y-2">
              {items.map((it, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <input className="input mb-1" placeholder="Description" value={it.description} onChange={e => updateItem(idx, 'description', e.target.value)} />
                    <div className="flex gap-1.5">
                      <input className="input w-16" type="number" min="0" step="any" placeholder="Qty" value={it.quantity} onChange={e => updateItem(idx, 'quantity', e.target.value)} />
                      <input className="input flex-1" type="number" min="0" step="any" placeholder="Unit Price" value={it.unit_price} onChange={e => updateItem(idx, 'unit_price', e.target.value)} />
                    </div>
                  </div>
                  {items.length > 1 && <button type="button" onClick={() => removeItem(idx)} className="btn-ghost p-2 mt-0.5"><Trash2 className="w-4 h-4 text-error-400" /></button>}
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Tax Rate (%)</label><input className="input" type="number" min="0" step="any" value={taxRate} onChange={e => setTaxRate(e.target.value)} /></div>
            <div><label className="label">Expires</label><input className="input" type="date" value={expiresAt} onChange={e => setExpiresAt(e.target.value)} /></div>
          </div>

          <div><label className="label">Notes</label><textarea className="input min-h-[50px]" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Project scope, terms, etc." /></div>

          <div className="card p-3 bg-navy-900 flex items-center justify-between">
            <div><p className="text-xs text-navy-300">Subtotal</p><p className="text-sm font-bold text-navy-100">{formatCurrency(subtotal)}</p></div>
            <div className="text-right"><p className="text-xs text-navy-300">Total (incl. tax)</p><p className="text-lg font-bold text-gold-400 font-display">{formatCurrency(total)}</p></div>
          </div>

          {error && <p className="text-xs text-error-400">{error}</p>}
          <div className="flex items-center gap-2 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Saving...' : 'Create Estimate'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
