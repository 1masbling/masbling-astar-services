# App Store & Google Play Deployment Guide

This guide covers testing, deploying, and marketing the Masbling Astar Services app to both the Apple App Store and Google Play Console.

---

## Current Architecture

This is a **Vite + React PWA** (Progressive Web App). It includes:
- `public/manifest.json` — PWA manifest for installability
- `public/sw.js` — Service worker for offline caching
- Mobile meta tags in `index.html` (apple-touch-icon, theme-color, standalone mode)

### Two paths to the app stores

| Path | Effort | Result |
|------|--------|--------|
| **PWA Install** | Zero — already done | Users install from browser; appears on home screen with icon |
| **Capacitor Wrapper** | Medium — requires native build | True native binary for App Store + Play Console submission |

---

## Phase 1: Testing (Beta)

### 1.1 Web Beta (now)
The app is deployable to any static host. For team testing:
1. Run `npm run build`
2. Deploy `dist/` to Netlify, Vercel, or any static host
3. Share the URL with testers
4. On mobile, testers can "Add to Home Screen" — it installs as an app

### 1.2 Expo Go Testing (for native builds)
If you convert to Expo for native store submission:
1. Install Expo CLI: `npm install -g eas-cli`
2. Log in: `eas login`
3. Build a development client: `eas build --profile development --platform ios`
4. Install Expo Go on your phone and scan the QR code

### 1.3 TestFlight (iOS beta)
1. `eas build --platform ios --auto-submit` (submits to TestFlight automatically)
2. In App Store Connect → TestFlight → add tester emails
3. Testers install TestFlight and accept the invite

### 1.4 Google Play Internal Testing
1. `eas build --platform android`
2. In Google Play Console → Testing → Internal testing → Create release
3. Upload the `.aab` file
4. Add tester email addresses
5. Share the testing link

---

## Phase 2: Deploy (Native App Store Submission)

### Prerequisites
- **Apple Developer Account**: $99/year at developer.apple.com
- **Google Play Developer Account**: $25 one-time at play.google.com/console

### 2.1 Converting to a Native App with Capacitor

Capacitor is already installed and configured in this project. The Android native project lives in `android/`.

**Config file:** `capacitor.config.ts`
- **App ID:** `com.masblingastar.services`
- **App Name:** Masbling Astar Services
- **Web Dir:** `dist` (the Vite build output)

**Build the Android App Bundle (.aab):**

```bash
# One command — builds web app, syncs to native project, generates .aab
npm run android:build
```

The `.aab` file will be at:
`android/app/build/outputs/bundle/release/app-release.aab`

If you need to open the project in Android Studio for signing or advanced config:
```bash
npm run cap:open
```

### 2.2 Generate a Signing Key

Before uploading to Google Play, you need to sign the .aab:

```bash
keytool -genkey -v -keystore astar-release.keystore -alias astar -keyalg RSA -keysize 2048 -validity 10000
```

Store this keystore file safely — you'll need it for every future update.

### 2.3 Google Play Console Submission

1. Go to [play.google.com/console](https://play.google.com/console)
2. Click **"Create app"**
   - App name: `Masbling Astar Services`
   - Default language: English (United States)
   - App or game: **App**
   - Free or paid: **Free**
3. **Dashboard → Set up your app** — complete all required tasks:
   - App access (no special access needed)
   - Ads: Declare if your app contains ads
   - Content rating: Complete the questionnaire
   - Target audience: Select 13+ or 18+
   - News app: No
   - Data safety: Fill out data collection disclosure
   - Government apps: No
   - Financial features: No
   - Privacy Policy URL: `https://www.masblingastarservices.com/privacy-policy`
4. **Testing → Internal testing → Create release**
   - Upload the `.aab` file from `android/app/build/outputs/bundle/release/app-release.aab`
   - Add release notes
   - Add tester email addresses
   - Click **Review release** then **Start rollout**
5. Testers receive a link to download the app from Play Store
6. After testing, go to **Production → Create release** to publish publicly
7. Review typically takes 1-3 days

### 2.4 iOS App Store Submission

If you want to target iOS later, add the iOS platform:
```bash
npm install @capacitor/ios
npx cap add ios
npm run build && npx cap sync ios
npx cap open ios
```

Then in Xcode:
1. Set signing team, bundle ID (`com.masblingastar.services`), and version
2. Product → Archive
3. Upload to App Store Connect
4. In App Store Connect: create app record, fill listing, upload screenshots, submit for review
5. Review typically takes 24-48 hours

---

## Phase 3: Marketing — App Store Listings

### App Name
Masbling Astar Services

### Subtitle (30 chars)
Gutter & Exterior Maintenance

### Category
Business / Productivity

### Keywords (App Store, 100 char limit)
gutter,eavestrough,cleaning,window caulking,downpipe,leak sealing,handyman,Brampton,GTA,exterior maintenance,vent cleaning,field service,dispatch,booking

### Short Description (Play Store, 80 char limit)
Book and manage gutter, window & exterior maintenance services in the GTA.

### Full Description (4000 char limit)

Masbling Astar Services is your all-in-one platform for professional gutter, eavestrough, and exterior maintenance services in Brampton and the Greater Toronto Area.

BOOK A SERVICE IN SECONDS
Schedule gutter cleaning, eavestrough repair, window caulking, window cleaning, vent cleaning, downpipe installation, leak sealing, and handyman services — right from your phone. Choose your preferred date and time window, and we'll handle the rest.

REAL-TIME JOB TRACKING
From estimate to completion, track every job through the pipeline. See scheduled appointments, technician assignments, and live job status updates so you always know what's happening.

PROFESSIONAL ESTIMATES
Get detailed, itemized estimates with transparent pricing. Approve or decline estimates directly in the app — no paperwork, no phone tag.

SECURE PAYMENTS
Pay invoices via e-Transfer or credit card through our secure Square checkout. Receive payment reminders and confirmations by SMS or email.

FIELD-READY OPERATIONS
Our technicians use the built-in field app to clock in and out, complete checklists, upload job photos, and update job notes — ensuring quality and accountability on every visit.

KEY SERVICES
- Gutter cleaning & repair
- Eavestrough installation & maintenance
- Window caulking & sealing
- Window cleaning
- Vent cleaning
- Downpipe installation & repair
- Leak detection & sealing
- General handyman services

WHY CHOOSE US
- Locally owned and operated in Brampton, ON
- Serving the entire Greater Toronto Area
- Licensed, insured, and experienced technicians
- Transparent pricing with no hidden fees
- Real-time updates and digital records
- Customer satisfaction guaranteed

Contact us at 437-440-4072 or visit masblingastarservices.com to get started today.

### App Store Screenshots Needed

| Device | Size | Count |
|--------|------|-------|
| iPhone 6.7" | 1290x2796 | At least 3 |
| iPhone 6.1" | 1179x2556 | At least 3 |
| iPad 12.9" | 2048x2732 | At least 3 (if supporting iPad) |

Suggested screenshots:
1. Dashboard overview with KPI stats
2. Online booking form with service selection
3. Job pipeline / dispatch board
4. Invoice & payment screen (Square checkout)
5. Field app with checklist & job completion

### Google Play Screenshots
- Minimum: 320px wide
- Maximum: 3840px wide
- At least 2 screenshots required, up to 8

### App Icon
- Source: Company logo at the URL in constants.ts
- iOS: 1024x1024 PNG, no transparency, no rounded corners (system applies mask)
- Android: 512x512 PNG, can have transparency

### Privacy Policy URL
Required by both stores. Create a page at:
`https://www.masblingastarservices.com/privacy-policy`

### Support URL
`https://www.masblingastarservices.com/support`
(or use `mailto:Masblingastar@gmail.com`)

---

## Phase 4: Post-Launch Marketing

### 1. Social Media
- Post on X (@Masblingastar), Instagram (@masblingastar), TikTok (@1masbling)
- Share before/after job photos
- Create short video walkthroughs of the booking flow

### 2. Local SEO
- Google Business Profile with app download link
- Service area pages for each GTA city (Brampton, Mississauga, Toronto, etc.)

### 3. In-App Referral
- Add a referral code system for existing customers to share the app
- Offer a discount on next service for successful referrals

### 4. Review Generation
- Use the built-in review request system to ask happy customers for app store reviews
- Respond to all reviews within 24 hours

---

## Build Commands Reference

| Task | Command |
|------|---------|
| Web build | `npm run build` |
| Type check | `npm run typecheck` |
| Lint | `npm run lint` |
| Capacitor copy | `npx cap copy` |
| Capacitor open iOS | `npx cap open ios` |
| Capacitor open Android | `npx cap open android` |
| EAS build iOS | `eas build --platform ios --auto-submit` |
| EAS build Android | `eas build --platform android` |
