import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const MAX_NAME_LEN = 200;
const MAX_PHONE_LEN = 50;
const MAX_EMAIL_LEN = 320;
const MAX_ADDRESS_LEN = 300;
const MAX_NOTES_LEN = 2000;
const MAX_REFERRER_LEN = 500;
const MAX_LEAD_SOURCE_LEN = 100;
const MAX_PER_HOUR = 5;
const MAX_PER_DAY = 15;

const URL_REGEX = /https?:\/\/|www\./i;
const SPAM_KEYWORDS = /\b(viagra|casino|seo|backlink|crypto|betting|gambling|loan)\b/i;
const PHONE_REGEX = /^[\d\s\-\(\)\+]{7,}$/;

// Every value below reaches the owner's inbox as markup. The spam filter only
// covers the customer-typed fields, and referrer/UTM arrive straight from the
// request body, so escape at the point of interpolation instead.
function escapeHtml(value: string): string {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function sendOwnerNotificationEmail(
  params: {
    name: string;
    phone: string;
    email: string;
    address: string;
    serviceLabel: string;
    date: string;
    timeWindow: string;
    notes: string;
    jobId: string | null;
    leadSource: string;
    referrer: string;
    utm: { utm_source?: string; utm_medium?: string; utm_campaign?: string } | null;
  },
  supabase: ReturnType<typeof createClient>,
): Promise<{ status: string }> {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  const ownerEmail = Deno.env.get("OWNER_EMAIL") || "Masblingastar@gmail.com";
  const subject = `New Booking: ${params.serviceLabel} — ${params.name} on ${params.date}`.slice(0, 200).replace(/[\r\n]/g, " ");

  if (!resendApiKey) {
    console.error("RESEND_API_KEY not set — owner email notification skipped");
    await supabase.from("notifications").insert({
      type: "email",
      recipient: ownerEmail,
      recipient_name: params.name,
      subject,
      body: "Owner booking notification — RESEND_API_KEY not configured",
      status: "pending",
      related_job_id: params.jobId,
      related_invoice_id: null,
      sent_at: null,
    });
    return { status: "pending" };
  }

  const companyName = "MASBLING A STAR SERVICES";

  const eName = escapeHtml(params.name);
  const ePhone = escapeHtml(params.phone);
  const eEmail = escapeHtml(params.email);
  const eAddress = escapeHtml(params.address);
  const eServiceLabel = escapeHtml(params.serviceLabel);
  const eDate = escapeHtml(params.date);
  const eTimeWindow = escapeHtml(params.timeWindow);
  const eNotes = escapeHtml(params.notes);
  const eJobId = params.jobId ? escapeHtml(params.jobId) : "";

  const notesRow = params.notes
    ? `<tr><td style="padding:8px 0;color:#94a3b8;font-size:13px;">Notes</td><td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eNotes}</td></tr>`
    : "";

  const leadSourceRow = params.leadSource
    ? `<tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0;color:#94a3b8;font-size:13px;">Lead Source</td><td style="padding:8px 0;color:#fbbf24;font-size:13px;font-weight:700;">${escapeHtml(params.leadSource)}</td></tr>`
    : "";

  const referrerRow = params.referrer
    ? `<tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0;color:#94a3b8;font-size:13px;">Referrer</td><td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${escapeHtml(params.referrer)}</td></tr>`
    : "";

  const utmParts: string[] = [];
  if (params.utm) {
    if (params.utm.utm_source) utmParts.push(`source: ${escapeHtml(params.utm.utm_source)}`);
    if (params.utm.utm_medium) utmParts.push(`medium: ${escapeHtml(params.utm.utm_medium)}`);
    if (params.utm.utm_campaign) utmParts.push(`campaign: ${escapeHtml(params.utm.utm_campaign)}`);
  }
  const utmRow = utmParts.length > 0
    ? `<tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0;color:#94a3b8;font-size:13px;">UTM</td><td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${utmParts.join(' · ')}</td></tr>`
    : "";

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0f172a;padding:32px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:520px;background:#1e293b;border-radius:12px;border:1px solid #334155;overflow:hidden;">
        <tr>
          <td style="background:#ca8a04;padding:20px 28px;">
            <p style="margin:0;font-size:11px;font-weight:700;letter-spacing:3px;color:#1c1917;text-transform:uppercase;">${companyName}</p>
            <h1 style="margin:4px 0 0;font-size:20px;color:#1c1917;font-weight:800;">New Booking Request</h1>
          </td>
        </tr>
        <tr>
          <td style="padding:24px 28px;">
            <p style="margin:0 0 20px;color:#94a3b8;font-size:14px;">A customer just submitted a booking through your website.</p>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;width:110px;">Customer</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;font-weight:600;">${eName}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Phone</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;"><a href="tel:${ePhone}" style="color:#fbbf24;text-decoration:none;">${ePhone}</a></td>
              </tr>
              ${params.email ? `<tr style="border-bottom:1px solid #334155;"><td style="padding:8px 0;color:#94a3b8;font-size:13px;">Email</td><td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eEmail}</td></tr>` : ""}
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Address</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eAddress}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Service</td>
                <td style="padding:8px 0;color:#fbbf24;font-size:13px;font-weight:700;">${eServiceLabel}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Date</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eDate}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Time</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eTimeWindow}</td>
              </tr>
              ${notesRow}
              ${leadSourceRow}
              ${referrerRow}
              ${utmRow}
            </table>
            ${params.jobId ? `<p style="margin:20px 0 0;font-size:12px;color:#475569;">Job ID: ${eJobId}</p>` : ""}
          </td>
        </tr>
        <tr>
          <td style="background:#0f172a;padding:16px 28px;border-top:1px solid #334155;">
            <p style="margin:0;font-size:12px;color:#475569;">This notification was sent automatically from your website booking form at masblingastarservices.com</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Booking Notifications <bookings@masblingastarservices.com>",
        to: [ownerEmail],
        subject,
        html,
      }),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      console.error("Owner email send failed:", res.status, errText);
      await supabase.from("notifications").insert({
        type: "email",
        recipient: ownerEmail,
        recipient_name: params.name,
        subject,
        body: errText.slice(0, 500) || `HTTP ${res.status}`,
        status: "failed",
        related_job_id: params.jobId,
        related_invoice_id: null,
        sent_at: null,
      });
      return { status: "failed" };
    }
    await supabase.from("notifications").insert({
      type: "email",
      recipient: ownerEmail,
      recipient_name: params.name,
      subject,
      body: "Owner booking notification sent via Resend",
      status: "sent",
      related_job_id: params.jobId,
      related_invoice_id: null,
      sent_at: new Date().toISOString(),
    });
    return { status: "sent" };
  } catch (err) {
    console.error("Owner email exception:", err);
    await supabase.from("notifications").insert({
      type: "email",
      recipient: ownerEmail,
      recipient_name: params.name,
      subject,
      body: String(err).slice(0, 500),
      status: "failed",
      related_job_id: params.jobId,
      related_invoice_id: null,
      sent_at: null,
    });
    return { status: "failed" };
  }
}

async function sendCustomerConfirmationEmail(
  params: {
    name: string;
    email: string;
    serviceLabel: string;
    date: string;
    timeWindow: string;
  },
  supabase: ReturnType<typeof createClient>,
): Promise<{ status: string }> {
  const resendApiKey = Deno.env.get("RESEND_API_KEY");
  const ownerEmail = Deno.env.get("OWNER_EMAIL") || "Masblingastar@gmail.com";
  const subject = `Your Booking Confirmation — ${params.serviceLabel} on ${params.date}`.slice(0, 200).replace(/[\r\n]/g, " ");

  if (!resendApiKey) {
    console.error("RESEND_API_KEY not set — customer email skipped");
    await supabase.from("notifications").insert({
      type: "email",
      recipient: params.email,
      recipient_name: params.name,
      subject,
      body: "Customer confirmation — RESEND_API_KEY not configured",
      status: "pending",
      related_job_id: null,
      related_invoice_id: null,
      sent_at: null,
    });
    return { status: "pending" };
  }

  const companyName = "MASBLING A STAR SERVICES";
  const eName = escapeHtml(params.name);
  const eServiceLabel = escapeHtml(params.serviceLabel);
  const eDate = escapeHtml(params.date);
  const eTimeWindow = escapeHtml(params.timeWindow);

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#0f172a;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0f172a;padding:32px 16px;">
    <tr><td align="center">
      <table width="100%" style="max-width:520px;background:#1e293b;border-radius:12px;border:1px solid #334155;overflow:hidden;">
        <tr>
          <td style="background:#ca8a04;padding:20px 28px;">
            <p style="margin:0;font-size:11px;font-weight:700;letter-spacing:3px;color:#1c1917;text-transform:uppercase;">${companyName}</p>
            <h1 style="margin:4px 0 0;font-size:20px;color:#1c1917;font-weight:800;">Booking Confirmation</h1>
          </td>
        </tr>
        <tr>
          <td style="padding:24px 28px;">
            <p style="margin:0 0 20px;color:#f1f5f9;font-size:15px;">Hi ${eName},</p>
            <p style="margin:0 0 20px;color:#94a3b8;font-size:14px;">We've received your booking request and our team will contact you within 24 hours to confirm your appointment. Here are the details:</p>
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;width:110px;">Service</td>
                <td style="padding:8px 0;color:#fbbf24;font-size:13px;font-weight:700;">${eServiceLabel}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Date</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eDate}</td>
              </tr>
              <tr style="border-bottom:1px solid #334155;">
                <td style="padding:8px 0;color:#94a3b8;font-size:13px;">Time</td>
                <td style="padding:8px 0;color:#f1f5f9;font-size:13px;">${eTimeWindow}</td>
              </tr>
            </table>
            <p style="margin:20px 0 0;color:#94a3b8;font-size:14px;">If you need to reschedule or have any questions, please reply to this email or call us. We look forward to serving you!</p>
          </td>
        </tr>
        <tr>
          <td style="background:#0f172a;padding:16px 28px;border-top:1px solid #334155;">
            <p style="margin:0;font-size:12px;color:#475569;">This confirmation was sent automatically from masblingastarservices.com</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Booking Notifications <bookings@masblingastarservices.com>",
        to: [params.email, ownerEmail],
        subject,
        html,
      }),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      console.error("Customer email send failed:", res.status, errText);
      await supabase.from("notifications").insert({
        type: "email",
        recipient: params.email,
        recipient_name: params.name,
        subject,
        body: errText.slice(0, 500) || `HTTP ${res.status}`,
        status: "failed",
        related_job_id: null,
        related_invoice_id: null,
        sent_at: null,
      });
      return { status: "failed" };
    }
    await supabase.from("notifications").insert({
      type: "email",
      recipient: params.email,
      recipient_name: params.name,
      subject,
      body: "Customer confirmation sent via Resend",
      status: "sent",
      related_job_id: null,
      related_invoice_id: null,
      sent_at: new Date().toISOString(),
    });
    return { status: "sent" };
  } catch (err) {
    console.error("Customer email exception:", err);
    await supabase.from("notifications").insert({
      type: "email",
      recipient: params.email,
      recipient_name: params.name,
      subject,
      body: String(err).slice(0, 500),
      status: "failed",
      related_job_id: null,
      related_invoice_id: null,
      sent_at: null,
    });
    return { status: "failed" };
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const {
      service_key,
      name,
      phone,
      email,
      address,
      date,
      timeWindow,
      notes,
      serviceLabel,
      honeypot,
      leadSource,
      referrer,
      utm,
    } = await req.json();

    // Honeypot: if filled, silently succeed (bot caught)
    if (honeypot) {
      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!service_key || !name || !phone || !address || !date || !timeWindow) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const trimmedName = String(name).trim().slice(0, MAX_NAME_LEN);
    const trimmedPhone = String(phone).trim().slice(0, MAX_PHONE_LEN);
    const trimmedEmail = email ? String(email).trim().slice(0, MAX_EMAIL_LEN) : "";
    const trimmedAddress = String(address).trim().slice(0, MAX_ADDRESS_LEN);
    const trimmedNotes = notes ? String(notes).trim().slice(0, MAX_NOTES_LEN) : "";
    const trimmedLeadSource = leadSource ? String(leadSource).trim().slice(0, MAX_LEAD_SOURCE_LEN) : "";
    const trimmedReferrer = referrer ? String(referrer).trim().slice(0, MAX_REFERRER_LEN) : "";

    const ALLOWED_LEAD_SOURCES = ['Google Search', 'Google Maps', 'Friend/Neighbor', 'Flyer/Sign', 'Facebook', 'Other'];
    const safeLeadSource = ALLOWED_LEAD_SOURCES.includes(trimmedLeadSource) ? trimmedLeadSource : "";

    let safeUtm: { utm_source?: string; utm_medium?: string; utm_campaign?: string } | null = null;
    if (utm && typeof utm === 'object') {
      const u: { utm_source?: string; utm_medium?: string; utm_campaign?: string } = {};
      if (typeof utm.utm_source === 'string') u.utm_source = utm.utm_source.slice(0, 200);
      if (typeof utm.utm_medium === 'string') u.utm_medium = utm.utm_medium.slice(0, 200);
      if (typeof utm.utm_campaign === 'string') u.utm_campaign = utm.utm_campaign.slice(0, 200);
      if (Object.keys(u).length > 0) safeUtm = u;
    }

    if (trimmedName.length < 2) {
      return new Response(JSON.stringify({ error: "Name is too short" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!PHONE_REGEX.test(trimmedPhone)) {
      return new Response(JSON.stringify({ error: "Invalid phone number" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Spam detection
    const allText = `${trimmedName} ${trimmedPhone} ${trimmedEmail} ${trimmedAddress} ${trimmedNotes}`;
    if (URL_REGEX.test(allText) || SPAM_KEYWORDS.test(allText)) {
      return new Response(JSON.stringify({ error: "Submission flagged as spam" }), {
        status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate date is not in the past
    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
      return new Response(JSON.stringify({ error: "Cannot book a date in the past" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Rate limiting by phone
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count: hourlyCount } = await supabase
      .from("jobs")
      .select("id", { count: "exact", head: true })
      .eq("customer_phone", trimmedPhone)
      .gte("created_at", oneHourAgo);

    if (hourlyCount !== null && hourlyCount >= MAX_PER_HOUR) {
      return new Response(JSON.stringify({ error: "Too many bookings from this phone number. Please try again later." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const { count: dailyCount } = await supabase
      .from("jobs")
      .select("id", { count: "exact", head: true })
      .eq("customer_phone", trimmedPhone)
      .gte("created_at", oneDayAgo);

    if (dailyCount !== null && dailyCount >= MAX_PER_DAY) {
      return new Response(JSON.stringify({ error: "Daily booking limit reached. Please call us at " + (Deno.env.get("COMPANY_PHONE") || "our office") + "." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let customerId: string | null = null;

    const { data: existing } = await supabase
      .from("customers")
      .select("id")
      .ilike("name", trimmedName)
      .eq("phone", trimmedPhone)
      .maybeSingle();

    if (existing) {
      customerId = existing.id;
    } else {
      const { data: newCustomer } = await supabase
        .from("customers")
        .insert({
          name: trimmedName,
          phone: trimmedPhone,
          email: trimmedEmail,
          address: trimmedAddress,
          notes: "",
        })
        .select("id")
        .single();
      if (newCustomer) customerId = newCustomer.id;
    }

    const { data: job } = await supabase
      .from("jobs")
      .insert({
        service_key,
        customer_id: customerId,
        customer_name: trimmedName,
        customer_phone: trimmedPhone,
        address: trimmedAddress,
        status: "estimate",
        urgent: false,
        value: 170,
        scheduled_date: date || null,
        time_window: timeWindow || null,
        technician_id: null,
        rating: null,
        notes: trimmedNotes,
        lead_source: safeLeadSource || null,
        referrer: trimmedReferrer || null,
        utm_data: safeUtm,
      })
      .select("id")
      .single();

    if (phone) {
      const smsBody = `Hi ${trimmedName.split(" ")[0] || "there"}, your booking for ${serviceLabel || service_key} on ${date} (${timeWindow}) has been received. We'll confirm your appointment shortly.`;

      let smsStatus = "pending";
      const twilioAccountSid = Deno.env.get("TWILIO_ACCOUNT_SID");
      const twilioAuthToken = Deno.env.get("TWILIO_AUTH_TOKEN");
      const twilioFromNumber = Deno.env.get("TWILIO_FROM_NUMBER");

      if (twilioAccountSid && twilioAuthToken && twilioFromNumber) {
        try {
          const toNumber = trimmedPhone.replace(/[^0-9]/g, "");
          const fullTo = toNumber.length === 10 ? `+1${toNumber}` : `+${toNumber}`;
          const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`;
          const authHeader = btoa(`${twilioAccountSid}:${twilioAuthToken}`);
          const smsResponse = await fetch(twilioUrl, {
            method: "POST",
            headers: {
              "Authorization": `Basic ${authHeader}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              From: twilioFromNumber,
              To: fullTo,
              Body: smsBody,
            }),
          });
          if (smsResponse.ok) {
            smsStatus = "sent";
          } else {
            smsStatus = "failed";
            const smsErr = await smsResponse.text().catch(() => "");
            console.error("Twilio SMS failed:", smsResponse.status, smsErr);
          }
        } catch (smsErr) {
          smsStatus = "failed";
          console.error("Twilio SMS exception:", smsErr);
        }
      } else {
        console.error("Twilio credentials not set — SMS notification skipped");
      }

      await supabase.from("notifications").insert({
        type: "sms",
        recipient: trimmedPhone,
        recipient_name: trimmedName,
        subject: "Booking Confirmation",
        body: smsBody,
        status: smsStatus,
        related_job_id: job?.id || null,
        related_invoice_id: null,
        sent_at: smsStatus === "sent" ? new Date().toISOString() : null,
      });
    }

    // Send email notifications in the background so the booking response returns quickly
    EdgeRuntime.waitUntil(
      sendOwnerNotificationEmail({
        name: trimmedName,
        phone: trimmedPhone,
        email: trimmedEmail,
        address: trimmedAddress,
        serviceLabel: serviceLabel || service_key,
        date,
        timeWindow,
        notes: trimmedNotes,
        jobId: job?.id || null,
        leadSource: safeLeadSource,
        referrer: trimmedReferrer,
        utm: safeUtm,
      }, supabase).catch((err) => console.error("Owner email uncaught:", err)),
    );

    if (trimmedEmail) {
      EdgeRuntime.waitUntil(
        sendCustomerConfirmationEmail({
          name: trimmedName,
          email: trimmedEmail,
          serviceLabel: serviceLabel || service_key,
          date,
          timeWindow,
        }, supabase).catch((err) => console.error("Customer email uncaught:", err)),
      );
    }

    return new Response(
      JSON.stringify({ success: true, jobId: job?.id }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("submit-booking error:", err);
    return new Response(
      JSON.stringify({ error: "We could not process your booking. Please try again or call us." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
