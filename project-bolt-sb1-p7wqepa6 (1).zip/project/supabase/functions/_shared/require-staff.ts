// Shared caller authorization for privileged edge functions.
//
// The platform's verify_jwt flag only proves a bearer token was signed by this
// project's JWT secret. The public anon key is exactly such a token and ships in
// every browser bundle, so verify_jwt alone does NOT establish that the caller is
// staff. This resolves the token to a real user and checks the staff role that
// only the service role can set (app_metadata, not the user-editable metadata).

import { createClient } from "npm:@supabase/supabase-js@2.57.4";

export interface StaffCheckResult {
  ok: boolean;
  status: number;
  error?: string;
  userId?: string;
}

export async function requireStaff(
  req: Request,
  supabaseUrl: string,
  serviceRoleKey: string,
): Promise<StaffCheckResult> {
  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();

  if (!token) {
    return { ok: false, status: 401, error: "Authentication required" };
  }

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  // The anon key is a valid project JWT but resolves to no user, so this call
  // is what separates "a token from this project" from "a signed-in person".
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data?.user) {
    return { ok: false, status: 401, error: "Authentication required" };
  }

  const appMetadata = (data.user.app_metadata || {}) as Record<string, unknown>;
  if (appMetadata.role !== "staff") {
    return { ok: false, status: 403, error: "Not authorized" };
  }

  return { ok: true, status: 200, userId: data.user.id };
}
