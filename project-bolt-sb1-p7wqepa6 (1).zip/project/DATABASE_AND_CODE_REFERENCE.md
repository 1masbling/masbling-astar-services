# Masbling Astar Services — Complete Database & Code Reference

**Generated:** 2026-08-21
**App:** Masbling Astar Services — Gutter & Exterior Maintenance
**Platform:** Web (Vite + React + TypeScript + Tailwind CSS) + Android (Capacitor)
**Backend:** Supabase (PostgreSQL + Auth + Edge Functions + Row Level Security)

---

## Table of Contents

1. [Database Overview](#1-database-overview)
2. [Table Schemas](#2-table-schemas)
3. [Row Level Security (RLS) Policies](#3-row-level-security-rls-policies)
4. [Edge Functions](#4-edge-functions)
5. [Database Migrations](#5-database-migrations)
6. [App Architecture](#6-app-architecture)
7. [Source File Inventory](#7-source-file-inventory)
8. [Company Configuration](#8-company-configuration)
9. [Android App Configuration](#9-android-app-configuration)

---

## 1. Database Overview

- **23 tables** in the `public` schema
- **RLS enabled** on every table
- **6 helper functions** (SECURITY DEFINER)
- **5 Edge Functions** deployed
- **26 migrations** applied

All tables use UUID primary keys (via `gen_random_uuid()`). Timestamps are `timestamptz` with `now()` defaults. Row Level Security requires authenticated staff JWTs for business tables; public-facing tables (booking submissions, deletion requests) allow anon inserts via edge functions.

---

## 2. Table Schemas

### campaigns
Marketing campaign tracking.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL |
| name | text | — | NOT NULL |
| status | text | 'draft' | NOT NULL |
| platform | text | 'Facebook' | NOT NULL |
| reach | integer | 0 | NOT NULL |
| leads | integer | 0 | NOT NULL |
| ads_running | boolean | false | NOT NULL |
| created_at | timestamptz | now() | NULL |

### captcha_tokens_used
Single-use captcha token tracking (prevents replay attacks).

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| token_id | text | — | NOT NULL (PK) |
| used_at | timestamptz | now() | NOT NULL |
| expires_at | timestamptz | — | NOT NULL |

### checklists
Job-specific task checklists.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| job_id | uuid | — | NOT NULL (PK) |
| template_name | text | '' | NOT NULL |
| item_text | text | — | NOT NULL |
| completed | boolean | false | NOT NULL |
| created_at | timestamptz | now() | NULL |

### company_settings
Single-row table (id=1) holding all company and website configuration.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | integer | 1 | NOT NULL (PK) |
| name | text | 'MASBLING A STAR SERVICES' | NOT NULL |
| short_name | text | 'Masbling Astar' | NOT NULL |
| tagline | text | 'Gutter & Exterior Maintenance' | NOT NULL |
| phone | text | '437-440-4072' | NOT NULL |
| email | text | 'Masblingastar@gmail.com' | NOT NULL |
| website | text | 'masblingastarservices.com' | NOT NULL |
| website_href | text | 'https://www.masblingastarservices.com' | NOT NULL |
| hq | text | '45 Bramalea Rd, Suite 208, Brampton ON L6T 2W4' | NOT NULL |
| logo_url | text | (external URL) | NOT NULL |
| etransfer_email | text | 'Masblingastar@gmail.com' | NOT NULL |
| etransfer_recipient | text | 'Masbling Astar Services' | NOT NULL |
| square_checkout_url | text | 'https://square.link/u/fhSUKcOa' | NOT NULL |
| google_review_url | text | (Google search URL) | NOT NULL |
| updated_at | timestamptz | now() | NOT NULL |
| hero_heading | text | — | NOT NULL |
| hero_subheading | text | '' | NOT NULL |
| about_heading | text | 'Built on Quality & Trust' | NOT NULL |
| about_paragraph_1 | text | '' | NOT NULL |
| about_paragraph_2 | text | '' | NOT NULL |
| about_paragraph_3 | text | '' | NOT NULL |
| cta_heading | text | 'Ready to Get Started?' | NOT NULL |
| cta_subheading | text | '' | NOT NULL |
| services_intro | text | '' | NOT NULL |
| process_intro | text | '' | NOT NULL |
| gallery_intro | text | '' | NOT NULL |
| testimonials_intro | text | '' | NOT NULL |
| faq_intro | text | '' | NOT NULL |
| contact_intro | text | 'Have a question or ready to book?...' | NOT NULL |
| hours_label | text | 'Mon – Sat' | NOT NULL |
| hours_value | text | '8:00 AM – 6:00 PM' | NOT NULL |

### csr_tickets
Customer service request tickets.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| job_id | uuid | — | NULL |
| customer_name | text | — | NOT NULL |
| subject | text | — | NOT NULL |
| status | text | 'open' | NOT NULL |
| priority | text | 'medium' | NOT NULL |
| created_at | timestamptz | now() | NULL |
| customer_id | uuid | — | NULL |

### customers
Customer directory.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| name | text | — | NOT NULL |
| email | text | '' | NULL |
| phone | text | '' | NULL |
| address | text | '' | NULL |
| notes | text | '' | NULL |
| created_at | timestamptz | now() | NULL |

### data_deletion_requests
GDPR/privacy data deletion requests from the public form.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| name | text | — | NOT NULL |
| email | text | — | NOT NULL |
| phone | text | — | NULL |
| account_identifier | text | — | NULL |
| reason | text | — | NULL |
| status | text | 'pending' | NOT NULL |
| submitted_at | timestamptz | now() | NOT NULL |
| resolved_at | timestamptz | — | NULL |
| staff_notes | text | — | NULL |
| created_at | timestamptz | now() | NOT NULL |

### estimate_line_items
Individual line items on an estimate.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| estimate_id | uuid | — | NOT NULL |
| description | text | — | NOT NULL |
| quantity | numeric | 1 | NOT NULL |
| unit_price | numeric | 0 | NOT NULL |
| sort_order | integer | 0 | NOT NULL |
| created_at | timestamptz | now() | NULL |

### estimates
Customer job estimates.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| number | text | — | NOT NULL |
| customer_id | uuid | — | NULL |
| customer_name | text | — | NOT NULL |
| job_id | uuid | — | NULL |
| status | text | 'draft' | NOT NULL |
| subtotal | numeric | 0 | NOT NULL |
| tax_rate | numeric | 0 | NOT NULL |
| total | numeric | 0 | NOT NULL |
| notes | text | '' | NULL |
| sent_at | timestamptz | — | NULL |
| expires_at | date | — | NULL |
| created_at | timestamptz | now() | NULL |

### invoices
Customer invoices linked to jobs.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| number | text | — | NOT NULL |
| job_id | uuid | — | NULL |
| customer_name | text | — | NOT NULL |
| amount | numeric | 0 | NOT NULL |
| status | text | 'draft' | NOT NULL |
| sent_at | timestamptz | — | NULL |
| paid_at | timestamptz | — | NULL |
| created_at | timestamptz | now() | NULL |
| customer_id | uuid | — | NULL |

### job_photos
Photo evidence attached to jobs.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| job_id | uuid | — | NOT NULL |
| photo_url | text | — | NOT NULL |
| caption | text | '' | NULL |
| created_at | timestamptz | now() | NULL |

### jobs
Core job/booking records — created from the public booking form or by staff.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| service_key | text | — | NOT NULL |
| customer_name | text | — | NOT NULL |
| customer_phone | text | '' | NOT NULL |
| address | text | '' | NOT NULL |
| status | text | 'estimate' | NOT NULL |
| urgent | boolean | false | NOT NULL |
| value | numeric | 0 | NOT NULL |
| scheduled_date | date | — | NULL |
| rating | integer | — | NULL |
| notes | text | '' | NULL |
| created_at | timestamptz | now() | NULL |
| customer_id | uuid | — | NULL |
| technician_id | uuid | — | NULL |
| time_window | text | — | NULL |
| lead_source | text | — | NULL |
| referrer | text | — | NULL |
| utm_data | jsonb | — | NULL |

### notifications
SMS/email notification log.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| type | text | 'sms' | NOT NULL |
| recipient | text | — | NOT NULL |
| recipient_name | text | '' | NOT NULL |
| subject | text | '' | NOT NULL |
| body | text | — | NOT NULL |
| status | text | 'sent' | NOT NULL |
| related_job_id | uuid | — | NULL |
| related_invoice_id | uuid | — | NULL |
| created_at | timestamptz | now() | NULL |
| sent_at | timestamptz | now() | NULL |

### payments
Payment records linked to invoices.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| invoice_id | uuid | — | NULL |
| customer_name | text | — | NOT NULL |
| amount | numeric | 0 | NOT NULL |
| method | text | 'etransfer' | NOT NULL |
| reference | text | '' | NOT NULL |
| status | text | 'pending' | NOT NULL |
| requested_at | timestamptz | now() | NULL |
| confirmed_at | timestamptz | — | NULL |
| notes | text | '' | NULL |
| created_at | timestamptz | now() | NULL |

### review_requests
Google review request tracking per job/customer.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| job_id | uuid | — | NULL |
| customer_id | uuid | — | NULL |
| customer_name | text | — | NOT NULL |
| status | text | 'pending' | NOT NULL |
| rating | integer | — | NULL |
| review_text | text | '' | NOT NULL |
| sent_at | timestamptz | — | NULL |
| responded_at | timestamptz | — | NULL |
| created_at | timestamptz | now() | NULL |

### schedules
Recurring maintenance schedules per customer.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| customer_name | text | — | NOT NULL |
| service_key | text | — | NOT NULL |
| address | text | '' | NULL |
| frequency | text | 'monthly' | NOT NULL |
| next_run | date | — | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |
| customer_id | uuid | — | NULL |

### services
Service catalog (what the company offers).

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| key | text | — | NOT NULL (UNIQUE) |
| label | text | — | NOT NULL |
| icon | text | 'Hammer' | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |

**Active services:** gutter, window-caulking, window-cleaning, vent, downpipes, leaks-sealing, handyman

### technicians
Staff/technician accounts.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| name | text | — | NOT NULL |
| role | text | 'Technician' | NOT NULL |
| phone | text | '' | NULL |
| color | text | 'gold' | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |
| auth_id | uuid | — | NULL (links to Supabase Auth user) |
| email | text | — | NULL |

### time_entries
Technician clock in/out time tracking.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| job_id | uuid | — | NULL |
| technician_id | uuid | — | NULL |
| clock_in | timestamptz | now() | NOT NULL |
| clock_out | timestamptz | — | NULL |
| duration_minutes | integer | 0 | NOT NULL |
| notes | text | '' | NULL |
| created_at | timestamptz | now() | NULL |

### website_faqs
FAQ entries for the public website.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| question | text | — | NOT NULL |
| answer | text | — | NOT NULL |
| display_order | integer | 0 | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |

### website_gallery
Gallery images for the public website.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| image_url | text | — | NOT NULL |
| alt_text | text | '' | NOT NULL |
| label | text | '' | NOT NULL |
| display_order | integer | 0 | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |

### website_service_areas
Service area list for the public website.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| name | text | — | NOT NULL |
| display_order | integer | 0 | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |

### website_testimonials
Customer testimonials for the public website.

| Column | Type | Default | Nullable |
|--------|------|---------|----------|
| id | uuid | gen_random_uuid() | NOT NULL (PK) |
| name | text | — | NOT NULL |
| text | text | — | NOT NULL |
| rating | integer | 5 | NOT NULL |
| location | text | '' | NOT NULL |
| display_order | integer | 0 | NOT NULL |
| active | boolean | true | NOT NULL |
| created_at | timestamptz | now() | NULL |

---

## 3. Row Level Security (RLS) Policies

All business tables follow the same pattern — 4 policies per table (SELECT, INSERT, UPDATE, DELETE), each scoped to the `authenticated` role where the JWT's `app_metadata.role` equals `'staff'`.

### Policy Pattern (applies to all staff tables)

```
SELECT: USING (auth.jwt()->app_metadata->>'role' = 'staff')
INSERT: WITH CHECK (auth.jwt()->app_metadata->>'role' = 'staff')
UPDATE: USING (auth.jwt()->app_metadata->>'role' = 'staff')
        WITH CHECK (auth.jwt()->app_metadata->>'role' = 'staff')
DELETE: USING (auth.jwt()->app_metadata->>'role' = 'staff')
```

### Tables with staff-only RLS (all 4 CRUD policies):
- campaigns
- checklists
- company_settings
- csr_tickets
- customers
- estimates
- estimate_line_items
- invoices
- job_photos
- jobs (writes staff-only; reads also staff-only)
- notifications
- payments
- review_requests
- schedules
- services
- technicians
- time_entries
- website_faqs
- website_gallery
- website_service_areas
- website_testimonials

### Tables with public access:
- **captcha_tokens_used** — RLS enabled, no policies (access only via service role key in edge functions)
- **data_deletion_requests** — public INSERT via edge function (with captcha verification), staff-only SELECT

### Helper Functions (SECURITY DEFINER):
1. `is_staff()` — checks if current JWT has staff role
2. `get_security_audit_summary()` — returns security audit counts
3. `get_rls_coverage()` — returns RLS coverage stats
4. `get_active_policies()` — returns active policy details
5. `get_function_audit()` — returns function audit info
6. `get_column_grants()` — returns column grant info

---

## 4. Edge Functions

All edge functions are deployed to Supabase and use Deno runtime. All include CORS headers.

### submit-booking (verifyJWT: false)
**Purpose:** Public booking form submission handler. Creates a job and customer record from the website booking form.
**Security features:**
- Honeypot field detection (hidden "website" field — bots fill it, humans don't)
- Captcha verification (math question, single-use token)
- Rate limiting: max 3 bookings/hour per phone, max 10/day per phone
- Input validation and trimming
- Auto-creates customer record if not existing (matches by name + phone)
- Lead attribution: captures referrer, UTM params, lead source

### submit-deletion-request (verifyJWT: false)
**Purpose:** Public data deletion request form handler (GDPR/privacy compliance).
**Security features:**
- Captcha verification
- Input validation
- Inserts into `data_deletion_requests` table with status 'pending'

### deletion-captcha (verifyJWT: false)
**Purpose:** Generates and returns a math captcha question with a single-use token. Used by both the booking form and the deletion request form.
**How it works:**
- Generates two random numbers and returns "X + Y = ?"
- Creates a token in the captcha system
- Token is single-use (marked used after one verification)

### create-staff (verifyJWT: true)
**Purpose:** Creates new staff member accounts. Requires an existing staff JWT.
**What it does:**
- Creates a Supabase Auth user with `app_metadata.role = 'staff'`
- Creates a matching record in the `technicians` table
- Links the auth user ID to `technicians.auth_id`

### security-audit (verifyJWT: false)
**Purpose:** Returns a security audit summary for the admin dashboard. Calls the SECURITY DEFINER helper functions to report RLS coverage, policy counts, function audit, and column grants.

### Shared modules:
- **_shared/captcha.ts** — captcha token generation and verification logic
- **_shared/require-staff.ts** — JWT staff role verification helper

---

## 5. Database Migrations

26 migrations applied in chronological order:

| # | Filename | Purpose |
|---|----------|---------|
| 1 | 20260722065004_create_schema.sql | Initial schema (services, jobs) |
| 2 | 20260722065122_seed_demo_data.sql | Demo data seed |
| 3 | 20260722065824_update_service_icons.sql | Update service icon names |
| 4 | 20260722151327_create_schema.sql | Re-created schema (clean rebuild) |
| 5 | 20260722151414_seed_demo_data.sql | Re-seeded demo data |
| 6 | 20260722170821_create_security_audit_helper_functions.sql | Security audit helper functions |
| 7 | 20260722172343_fix_security_definer_function_permissions.sql | Fix SECURITY DEFINER permissions |
| 8 | 20260722231318_add_customers_technicians_dispatch.sql | Customers, technicians, dispatch tables |
| 9 | 20260723005938_add_estimates_timekeeping_reviews_notifications.sql | Estimates, time entries, reviews, notifications |
| 10 | 20260723011935_add_payments_table.sql | Payments table |
| 11 | 20260723051536_tighten_rls_require_auth_for_writes.sql | RLS: require auth for all writes |
| 12 | 20260723141756_add_staff_account_fields_to_technicians.sql | Staff account fields on technicians |
| 13 | 20260723141805_add_staff_account_fields_to_technicians.sql | Staff account fields (duplicate) |
| 14 | 20260723170930_lock_down_select_policies_require_auth.sql | Lock SELECT policies to auth |
| 15 | 20260723172057_replace_always_true_policies_with_is_staff_check.sql | Replace permissive policies |
| 16 | 20260723172704_inline_staff_check_into_rls_policies.sql | Inline staff check into RLS |
| 17 | 20260723175826_create_data_deletion_requests_table.sql | Data deletion requests table |
| 18 | 20260723233833_lock_down_deletion_requests_insert.sql | Lock down deletion insert |
| 19 | 20260725030603_merge_eavesdrop_into_gutter.sql | Merge eavesdrop service into gutter |
| 20 | 20260803052632_create_company_settings_table.sql | Company settings table |
| 21 | 20260817012400_create_website_content_tables.sql | Website content tables (FAQs, gallery, testimonials, service areas) |
| 22 | 20260819110201_add_lead_attribution_to_jobs.sql | Lead attribution columns on jobs |
| 23 | 20260819111021_scope_business_table_reads_to_staff.sql | Scope business table reads to staff |
| 24 | 20260819111143_scope_deletion_requests_reads_to_staff.sql | Scope deletion requests to staff |
| 25 | 20260819111159_create_captcha_single_use_claim_table.sql | Captcha single-use claim table |
| 26 | 20260819111704_drop_permissive_deletion_request_read.sql | Drop permissive deletion read policy |

---

## 6. App Architecture

### Tech Stack
- **Frontend:** React 18 + TypeScript + Tailwind CSS 3
- **Build tool:** Vite 5
- **Icons:** lucide-react + custom inline SVGs (ServiceIcon, SocialIcon)
- **Backend:** Supabase (PostgreSQL, Auth, Edge Functions, RLS)
- **Mobile:** Capacitor 8 (Android)
- **No additional npm packages** beyond the core stack

### Routing
The app uses hash-based routing (no react-router):
- `#booking` — Public booking form (no auth required)
- `#data-deletion` — Public data deletion request form (no auth)
- `#staff` — Staff sign-in page
- (default) — Public website
- After auth: in-app navigation between Dashboard, Pipeline, Dispatch, Customers, Estimates, Operations, Billing, Marketing, Settings

### Auth Flow
- Supabase email/password auth
- JWT `app_metadata.role` = `'staff'` grants access to business tables via RLS
- Technicians with `auth_id` matching the logged-in user get the Field App (mobile-optimized view)
- Staff without technician linkage get the full admin dashboard
- `onAuthStateChange` handles session management

### Data Flow
```
App.tsx
  ├── AuthProvider (auth.tsx) — Supabase auth state
  └── DataProvider (data.tsx) — loads services, technicians from Supabase
       └── AppContent
            ├── BrandHeader — company logo, contact, social links
            ├── Navigation — sidebar nav
            └── View components (Dashboard, Pipeline, etc.)
```

### Views (12 total)
| View | File | Lines | Purpose |
|------|------|-------|---------|
| Dashboard | Dashboard.tsx | 243 | KPI overview, quick actions |
| Pipeline | Pipeline.tsx | 767 | Kanban board (estimate → scheduled → in-progress → complete) |
| Dispatch | Dispatch.tsx | 563 | Job scheduling by date/technician |
| Customers | Customers.tsx | 270 | Customer directory CRUD |
| Estimates | Estimates.tsx | 340 | Estimate builder with line items |
| Operations | Operations.tsx | 760 | CSR tickets, scheduling, checklists, camera |
| Billing | Billing.tsx | 805 | Invoices, payments, e-transfer tracking |
| Marketing | Marketing.tsx | 235 | Campaign tracking |
| Booking | Booking.tsx | 438 | Public 3-step booking form |
| DataDeletion | DataDeletion.tsx | 288 | Public GDPR deletion request form |
| Website | Website.tsx | 838 | Full public website (hero, services, gallery, testimonials, FAQ, contact) |
| Settings | Settings.tsx | 568 | Company settings, website content editor, staff management |
| FieldApp | FieldApp.tsx | 473 | Mobile technician app (job list, checklists, time tracking, photos) |
| SignIn | SignIn.tsx | 95 | Staff sign-in page |

### Components (14 total)
| Component | File | Lines | Purpose |
|-----------|------|-------|---------|
| BrandHeader | BrandHeader.tsx | 113 | Top header with logo, phone, social icons |
| Navigation | Navigation.tsx | 87 | Sidebar navigation |
| ServiceChips | ServiceChips.tsx | 43 | Service filter chips |
| ServiceIcon | ServiceIcon.tsx | 126 | Custom inline SVG service icons (7 services) |
| SocialIcon | SocialIcon.tsx | 61 | Custom inline SVG social brand icons (Instagram, WhatsApp, TikTok, X) |
| BeforeAfterSlider | BeforeAfterSlider.tsx | 99 | Before/after photo comparison slider |
| StatusBadges | StatusBadges.tsx | 26 | Job/invoice status badges |
| JobMap | JobMap.tsx | 148 | Map view of jobs by location |
| GlancePanel | GlancePanel.tsx | 363 | Dashboard glance stats panel |
| EstimateTemplate | EstimateTemplate.tsx | 146 | Printable estimate template |
| CsrAiAssistant | CsrAiAssistant.tsx | 325 | AI-powered CSR assistant |
| VoiceBookingAssistant | VoiceBookingAssistant.tsx | 527 | Voice-driven booking assistant |
| SecurityAudit | SecurityAudit.tsx | 292 | Security audit dashboard widget |

### Lib files (7 total)
| File | Lines | Purpose |
|------|-------|---------|
| supabase.ts | 10 | Supabase client initialization |
| auth.tsx | 62 | Auth context provider |
| data.tsx | 405 | Data context provider (services, technicians) |
| constants.ts | 139 | Company info, statuses, nav items, socials, icons |
| types.ts | 288 | TypeScript interfaces for all entities |
| format.ts | 51 | Currency/date formatting helpers |
| export.ts | 33 | CSV export helper |
| speech.d.ts | 57 | Web Speech API type declarations |

---

## 7. Source File Inventory

### Total: ~10,084 lines of code across 35 source files

```
src/
├── App.tsx                          (206 lines)  Main app shell, routing, auth gate
├── main.tsx                         (entry point)
├── index.css                        (Tailwind + custom styles)
├── vite-env.d.ts
├── components/
│   ├── BeforeAfterSlider.tsx        (99 lines)
│   ├── BrandHeader.tsx              (113 lines)
│   ├── CsrAiAssistant.tsx           (325 lines)
│   ├── EstimateTemplate.tsx         (146 lines)
│   ├── GlancePanel.tsx              (363 lines)
│   ├── JobMap.tsx                   (148 lines)
│   ├── Navigation.tsx               (87 lines)
│   ├── SecurityAudit.tsx            (292 lines)
│   ├── ServiceChips.tsx             (43 lines)
│   ├── ServiceIcon.tsx              (126 lines)  Custom SVG service icons
│   ├── SocialIcon.tsx               (61 lines)   Custom SVG social brand icons
│   ├── StatusBadges.tsx             (26 lines)
│   └── VoiceBookingAssistant.tsx    (527 lines)
├── lib/
│   ├── auth.tsx                     (62 lines)
│   ├── constants.ts                 (139 lines)
│   ├── data.tsx                     (405 lines)
│   ├── export.ts                    (33 lines)
│   ├── format.ts                    (51 lines)
│   ├── speech.d.ts                  (57 lines)
│   ├── supabase.ts                  (10 lines)
│   └── types.ts                     (288 lines)
└── views/
    ├── Billing.tsx                  (805 lines)
    ├── Booking.tsx                  (438 lines)
    ├── Customers.tsx                (270 lines)
    ├── Dashboard.tsx                (243 lines)
    ├── DataDeletion.tsx             (288 lines)
    ├── Dispatch.tsx                 (563 lines)
    ├── Estimates.tsx                (340 lines)
    ├── FieldApp.tsx                 (473 lines)
    ├── Marketing.tsx                (235 lines)
    ├── Operations.tsx               (760 lines)
    ├── Pipeline.tsx                 (767 lines)
    ├── Settings.tsx                 (568 lines)
    ├── SignIn.tsx                   (95 lines)
    └── Website.tsx                  (838 lines)
```

---

## 8. Company Configuration

| Setting | Value |
|---------|-------|
| Legal Name | MASBLING A STAR SERVICES |
| Short Name | Masbling Astar |
| Tagline | Gutter & Exterior Maintenance |
| Phone | 437-440-4072 |
| Email | Masblingastar@gmail.com |
| Website | masblingastarservices.com |
| HQ | 45 Bramalea Rd, Suite 208, Brampton ON L6T 2W4 |
| Hours | Mon – Sat, 8:00 AM – 6:00 PM |
| e-Transfer Email | Masblingastar@gmail.com |
| e-Transfer Recipient | Masbling Astar Services |
| Square Checkout | https://square.link/u/fhSUKcOa |
| Google Review | https://www.google.com/search?q=masbling+a+star+services+brampton |

### Social Media Links
| Platform | URL | Icon |
|----------|-----|------|
| X (Twitter) | https://x.com/Masblingastar@gmail.com | Custom X SVG (black) |
| Instagram | https://instagram.com/masblingastar | Custom Instagram SVG (gradient) |
| TikTok | https://tiktok.com/@1masbling | Custom TikTok SVG (cyan/red) |
| WhatsApp | https://api.whatsapp.com/send?phone=4374404072 | Custom WhatsApp SVG (green) |

### Service Catalog
| Key | Label | Icon |
|-----|-------|------|
| gutter | Gutter Cleaning | Custom gutter SVG (blue) |
| window-caulking | Window Caulking | Custom window + caulking SVG |
| window-cleaning | Window Cleaning | Custom window + squeegee SVG |
| vent | Vent Cleaning | Custom vent grille SVG |
| downpipes | Downpipes | Custom downpipe SVG |
| leaks-sealing | Leaks Sealing | Custom droplet + patch SVG |
| handyman | Handyman Fixes | Custom hammer SVG |

### Job Status Flow
`estimate` → `scheduled` → `in-progress` → `complete`

### Invoice Statuses
`draft` → `sent` → `paid` / `overdue`

### Estimate Statuses
`draft` → `sent` → `approved` / `declined` / `expired`

---

## 9. Android App Configuration

| Setting | Value |
|---------|-------|
| App ID | com.masblingastar.services |
| App Name | Masbling Astar Services |
| Web Dir | dist |
| Android Scheme | https |
| Background Color | #0a1628 (navy) |
| Build Command | npm run android:build |
| Package | npm run build && npx cap sync android && cd android && ./gradlew bundleRelease |

### Android Build Steps
1. `npm run build` — builds the web app to `dist/`
2. `npx cap sync android` — copies web assets to Android project
3. `cd android && ./gradlew bundleRelease` — builds the AAB for Play Store

### Deployed Files
- AndroidManifest.xml — app permissions and configuration
- Splash screens in all densities (portrait + landscape)
- App icon in all densities
- Cordova/Capacitor runtime files

---

*This document is a complete snapshot of the database schema, edge functions, app architecture, and configuration as of 2026-08-21. Keep this as your reference for future development, audits, or when working with any developer on the project.*
